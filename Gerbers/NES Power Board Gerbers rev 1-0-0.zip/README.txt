Project: NES Power PCB

Engineer: Matthew Spinks
Work Phone:
Evening Phone:

Address:


********************************************************************************

Unit = Inches
Format = 2:4
Filetype = 274X

Dimensions:
X = 2.738"
Y = 2.866"

Layer Count = 2
Thickness = 0.062"
Copper Wt. = 1 oz
Silkscreen: Both Sides

Files:

.DRL    Binary Drill File
.GBL    Bottom Copper
.GBO    Bottom Silkscreen
.GBS    Bottom Soldermask
.GD1    Drill Drawing
.GG1    Drill Guide
.GM1	Board Outline
.GTL    Top Copper
.GTO    Top Silkscreen
.GTS    Top Soldermask
.TXT    NC Drill File